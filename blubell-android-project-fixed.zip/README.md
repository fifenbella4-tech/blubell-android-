# ★♡Blubell♡★ Android starter

A small native Android habit tracker built with Kotlin and Jetpack Compose.

## Current starter features
- Morning habit checklist
- Add custom habits
- Required written self-reported proof before a habit counts as complete
- Optional image selection for a check-in
- Local saving on the device
- Daily progress display

## Important limitations
- This starter does not yet block or unlock other Android apps.
- Written notes are self-reported, not independently verified.
- Photo selection currently saves the selected URI string. Long-term photo persistence and permission handling should be tested and improved before relying on it.
- This is an early build for testing, not a finished production app.

## Build
Open with Android Studio or run `./gradlew assembleDebug` in an environment with JDK 17 and Android SDK support.

The GitHub Actions workflow provided separately builds a debug APK and uploads it as an artifact.
