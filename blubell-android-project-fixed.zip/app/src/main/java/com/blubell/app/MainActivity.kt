package com.blubell.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

private val Rose = Color(0xFFF7DCE8)
private val Berry = Color(0xFF9D4771)
private val Ink = Color(0xFF352633)
private val Cream = Color(0xFFFFFBFD)

data class Habit(
    val id: Long,
    val title: String,
    val note: String = "",
    val photoUri: String = "",
    val completedDate: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BlubellApp() }
    }
}

@Composable
fun BlubellApp() {
    val context = LocalContext.current
    val today = LocalDate.now().toString()
    val prefs = remember { context.getSharedPreferences("blubell", Context.MODE_PRIVATE) }
    var habits by remember { mutableStateOf(loadHabits(prefs)) }
    var editing by remember { mutableStateOf<Habit?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var newHabit by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }

    fun persist(updated: List<Habit>) {
        habits = updated
        saveHabits(prefs, updated)
    }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        photoUri = uri?.toString().orEmpty()
    }

    val completed = habits.count { it.completedDate == today && it.note.isNotBlank() }
    val allDone = habits.isNotEmpty() && completed == habits.size

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Berry,
            onPrimary = Color.White,
            secondary = Color(0xFFC47EA0),
            background = Cream,
            surface = Color.White,
            onSurface = Ink
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Cream) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("★♡Blubell♡★", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Berry)
                Text("Tiny habits, lovely mornings 🌷", color = Ink)
                Card(colors = CardDefaults.cardColors(containerColor = Rose), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Your morning glow-up", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
                        Text("$completed of ${habits.size} habits have today's written proof", color = Ink)
                        LinearProgressIndicator(
                            progress = { if (habits.isEmpty()) 0f else completed.toFloat() / habits.size },
                            modifier = Modifier.fillMaxWidth(),
                            color = Berry,
                            trackColor = Color.White
                        )
                        Text(
                            if (allDone) "Routine complete! Celebrate your effort ✨"
                            else "One small step at a time. You've got this 💗",
                            color = Ink
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { showAdd = true }, shape = RoundedCornerShape(14.dp)) { Text("+ Add habit") }
                    OutlinedButton(onClick = {
                        persist(habits.map { it.copy(note = "", photoUri = "", completedDate = "") })
                        status = "Today's check-ins cleared."
                    }, shape = RoundedCornerShape(14.dp)) { Text("Reset check-ins") }
                }

                if (status.isNotBlank()) Text(status, color = Berry)

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(habits, key = { it.id }) { habit ->
                        val done = habit.completedDate == today && habit.note.isNotBlank()
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = if (done) Rose else Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(if (done) "💗" else "♡", style = MaterialTheme.typography.headlineSmall)
                                Column(Modifier.weight(1f)) {
                                    Text(habit.title, fontWeight = FontWeight.SemiBold, color = Ink)
                                    Text(if (done) "Proof saved for today ✨" else "Tap to add written proof", style = MaterialTheme.typography.bodySmall, color = Berry)
                                }
                                Button(onClick = {
                                    editing = habit
                                    note = if (done) habit.note else ""
                                    photoUri = if (done) habit.photoUri else ""
                                }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
                                    Text(if (done) "Edit" else "Check in")
                                }
                            }
                        }
                    }
                }
                Text(
                    "Proof is self-reported. This first version does not lock other Android apps yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Berry
                )
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Add a tiny habit 🌸") },
            text = {
                OutlinedTextField(
                    value = newHabit,
                    onValueChange = { newHabit = it },
                    label = { Text("Habit name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val title = newHabit.trim()
                    if (title.isNotEmpty()) {
                        persist(habits + Habit(System.currentTimeMillis(), title))
                        newHabit = ""
                        showAdd = false
                    }
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
        )
    }

    editing?.let { habit ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Proof for ${habit.title}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Write a short note about completing this habit. A photo is optional.")
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Your written proof (required)") },
                        minLines = 3
                    )
                    OutlinedButton(onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text(if (photoUri.isBlank()) "Add optional photo" else "Photo selected ✓") }
                    if (photoUri.isNotBlank()) {
                        Text("A photo is selected for this check-in.", style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { photoUri = "" }) { Text("Remove photo") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (note.trim().isNotEmpty()) {
                        persist(habits.map {
                            if (it.id == habit.id) it.copy(note = note.trim(), photoUri = photoUri, completedDate = today)
                            else it
                        })
                        status = "Proof saved for ${habit.title} 💗"
                        editing = null
                    } else {
                        status = "Please add a written note before checking in."
                    }
                }) { Text("Save proof") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } }
        )
    }
}

private fun loadHabits(prefs: android.content.SharedPreferences): List<Habit> {
    val raw = prefs.getString("habits", null)
    if (raw == null) {
        val defaults = listOf(
            Habit(1, "Drink a glass of water"),
            Habit(2, "Make my bed"),
            Habit(3, "Dance or move for 10 minutes"),
            Habit(4, "Brush my teeth"),
            Habit(5, "Read, pray, or reflect")
        )
        saveHabits(prefs, defaults)
        return defaults
    }
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Habit(
                id = o.optLong("id"),
                title = o.optString("title"),
                note = o.optString("note"),
                photoUri = o.optString("photoUri"),
                completedDate = o.optString("completedDate")
            )
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun saveHabits(prefs: android.content.SharedPreferences, habits: List<Habit>) {
    val arr = JSONArray()
    habits.forEach { h ->
        arr.put(JSONObject().apply {
            put("id", h.id)
            put("title", h.title)
            put("note", h.note)
            put("photoUri", h.photoUri)
            put("completedDate", h.completedDate)
        })
    }
    prefs.edit().putString("habits", arr.toString()).apply()
}
